<?php
/**
 * Plugin Name: Gradient Text Widget Alex
 * Plugin URI: https://alexwp.ru/plugins/elementor-gradient-text-widget
 * Description:  Этот плагин добавляет виджет в Elementor для создания градиентного текста
 * Version: 1.2
 * Author: Алексей Довгун
 * Author URI: https://alexwp.ru/plugins
 * License: GPLv3 
 * Text Domain: gradient-text-widget-alex
 */

/**
 * Детали:
 * Версия плагина: 1.2
 * Автор: Алексей Довгун
 * Описание: Этот плагин добавляет виджет в Elementor для создания градиентного текста с возможностью выбора шрифта Google, стиля, толщины шрифта и других параметров.
 * Для использования, просто добавьте виджет на страницу в Elementor.
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Подключение файлов с функционалом
function egtw_load_widget() {
    // Подключаем файл с виджетом
    require_once( plugin_dir_path( __FILE__ ) . 'includes/widget.php' );
}
add_action( 'elementor/widgets/widgets_registered', 'egtw_load_widget' );

// Регистрация стилей
function egtw_register_styles() {
    wp_enqueue_style( 'egtw-widget-styles', plugin_dir_url( __FILE__ ) . 'css/style.css' );
}
add_action( 'wp_enqueue_scripts', 'egtw_register_styles' );

// Загрузка текстового домена для перевода
function gradient_text_widget_load_textdomain() {
    load_plugin_textdomain( 'elementor-gradient-text-widget', false, plugin_dir_path( __FILE__ ) . 'languages' );
}
add_action( 'plugins_loaded', 'gradient_text_widget_load_textdomain' );
