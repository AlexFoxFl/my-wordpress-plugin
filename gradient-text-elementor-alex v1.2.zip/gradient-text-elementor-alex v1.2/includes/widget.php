<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Защита от прямого доступа

class Gradient_Text_Widget extends Widget_Base {

    public function get_name() {
        return 'gradient_text_widget';
    }

    public function get_title() {
        return __( 'Gradient Text', 'elementor-gradient-text-widget' );
    }

    public function get_icon() {
        return 'eicon-text';
    }

    public function get_categories() {
        return [ 'basic' ];
    }

    protected function _register_controls() {
        // Вкладка "Content"
        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Content', 'elementor-gradient-text-widget' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'text',
            [
                'label' => __( 'Text', 'elementor-gradient-text-widget' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'Gradient Text', 'elementor-gradient-text-widget' ),
                'dynamic' => [ 'active' => true ],
            ]
        );

        $this->add_control(
            'html_tag',
            [
                'label' => __( 'HTML Tag', 'elementor-gradient-text-widget' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'p'  => 'Paragraph',
                    'div' => 'Div',
                    'span' => 'Span',
                ],
                'default' => 'div',
            ]
        );

        $this->add_control(
            'link',
            [
                'label' => __( 'Link', 'elementor-gradient-text-widget' ),
                'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'elementor-gradient-text-widget' ),
                'dynamic' => [ 'active' => true ],
            ]
        );

        $this->add_control(
            'icon_position',
            [
                'label' => __( 'Icon Position', 'elementor-gradient-text-widget' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'before' => __( 'Before Text', 'elementor-gradient-text-widget' ),
                    'after' => __( 'After Text', 'elementor-gradient-text-widget' ),
                ],
                'default' => 'before',
            ]
        );

        $this->add_control(
            'icon',
            [
                'label' => __( 'Icon', 'elementor-gradient-text-widget' ),
                'type' => Controls_Manager::ICONS,
            ]
        );

        $this->end_controls_section();

        // Вкладка "Style"
        $this->start_controls_section(
            'style_section',
            [
                'label' => __( 'Style', 'elementor-gradient-text-widget' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'color_one',
            [
                'label' => __( 'First Color', 'elementor-gradient-text-widget' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#ff7e5f',
            ]
        );

        $this->add_control(
            'color_two',
            [
                'label' => __( 'Second Color', 'elementor-gradient-text-widget' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#feb47b',
            ]
        );

        $this->add_control(
            'gradient_angle',
            [
                'label' => __( 'Gradient Angle', 'elementor-gradient-text-widget' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'min' => 0,
                    'max' => 360,
                    'step' => 1,
                ],
                'default' => [
                    'unit' => 'deg',
                    'size' => 45,
                ],
            ]
        );

        $this->add_control(
            'font_family',
            [
                'label' => __( 'Font Family', 'elementor-gradient-text-widget' ),
                'type' => Controls_Manager::FONT,
                'selectors' => [
                    '{{WRAPPER}} .gradient-text' => 'font-family: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'font_weight',
            [
                'label' => __( 'Font Weight', 'elementor-gradient-text-widget' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '100' => '100',
                    '200' => '200',
                    '300' => '300',
                    '400' => '400',
                    '500' => '500',
                    '600' => '600',
                    '700' => '700',
                    '800' => '800',
                    '900' => '900',
                ],
                'default' => '400',
            ]
        );

        $this->add_control(
            'font_style',
            [
                'label' => __( 'Font Style', 'elementor-gradient-text-widget' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'normal' => 'Normal',
                    'italic' => 'Italic',
                ],
                'default' => 'normal',
            ]
        );

        $this->add_responsive_control(
            'font_size',
            [
                'label' => __( 'Font Size', 'elementor-gradient-text-widget' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em', 'rem', 'vw' ],
                'range' => [
                    'px' => [ 'min' => 10, 'max' => 200 ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 40,
                ],
                'selectors' => [
                    '{{WRAPPER}} .gradient-text' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_size',
            [
                'label' => __( 'Icon Size', 'elementor-gradient-text-widget' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em', 'rem', 'vw' ],
                'range' => [
                    'px' => [ 'min' => 10, 'max' => 100 ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 24,
                ],
                'selectors' => [
                    '{{WRAPPER}} .gradient-text-container .elementor-icon' => 'font-size: {{SIZE}}{{UNIT}}; vertical-align: middle;',
                ],
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => __( 'Icon Color', 'elementor-gradient-text-widget' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#000000',
                'selectors' => [
                    '{{WRAPPER}} .gradient-text-container .elementor-icon svg' => 'fill: {{VALUE}} !important;',
                    '{{WRAPPER}} .gradient-text-container .elementor-icon i' => 'color: {{VALUE}} !important;',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_margin',
            [
                'label' => __( 'Icon Margin', 'elementor-gradient-text-widget' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', 'rem', 'vw' ],
                'default' => [
                    'top' => '0',
                    'right' => '10',
                    'bottom' => '0',
                    'left' => '10',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .gradient-text-container .elementor-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        $tag = $settings['html_tag'];
        $gradient_style = "background: linear-gradient({$settings['gradient_angle']['size']}deg, {$settings['color_one']}, {$settings['color_two']});
                           -webkit-background-clip: text;
                           color: transparent;
                           font-family: {$settings['font_family']};
                           font-weight: {$settings['font_weight']};
                           font-style: {$settings['font_style']};";

        $link_open = '';
        $link_close = '';
        if (!empty($settings['link']['url'])) {
            $this->add_link_attributes('link', $settings['link']);
            $link_open = '<a ' . $this->get_render_attribute_string('link') . '>';
            $link_close = '</a>';
        }

        echo '<div class="gradient-text-container" style="display: flex; align-items: center;">';
        echo $link_open;

        if (!empty($settings['icon']['value']) && $settings['icon_position'] === 'before') {
            echo '<span class="elementor-icon" style="vertical-align: middle;">';
            Icons_Manager::render_icon($settings['icon'], ['aria-hidden' => 'true']);
            echo '</span>';
        }

        echo "<{$tag} class='gradient-text' style='" . esc_attr($gradient_style) . "; display: inline-block; margin: 0;'>"; // Убираем внешние отступы
        echo esc_html($settings['text']);
        echo "</{$tag}>";

        if (!empty($settings['icon']['value']) && $settings['icon_position'] === 'after') {
            echo '<span class="elementor-icon" style="vertical-align: middle;">';
            Icons_Manager::render_icon($settings['icon'], ['aria-hidden' => 'true']);
            echo '</span>';
        }

        echo $link_close;
        echo '</div>';
    }
}

Plugin::instance()->widgets_manager->register_widget_type( new Gradient_Text_Widget() );